// import { Component } from '@angular/core';
// import { IonicPage, NavController, NavParams } from 'ionic-angular';

// /**
//  * Generated class for the CommentPage page.
//  *
//  * See http://ionicframework.com/docs/components/#navigation for more info
//  * on Ionic pages and navigation.
//  */
// @IonicPage()
// @Component({
//   selector: 'page-comment',
//   templateUrl: 'comment.html',
// })
// export class CommentPage {

//   constructor(public navCtrl: NavController, public navParams: NavParams) {
//   }

//   ionViewDidLoad() {
//     console.log('ionViewDidLoad CommentPage');
//   }

// }

import { Component } from '@angular/core';
import { Http } from '@angular/http';
import {IonicPage, NavController,NavParams,ViewController} from 'ionic-angular';
 
/*
  Generated class for the CommentPage page.
 
  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
   selector: 'page-comment',
   templateUrl: 'comment.html',
})

export class CommentPage 
{ 
  constructor(private navCtrl: NavController, private viewCtrl: ViewController, private params: NavParams, private http: Http) {}
 
  doComment(value, event)
  {
    console.log(value);
    console.log("qdfqwfqwdhgqw" + this.params.data.url);

    this.http.post(this.params.data.url, value).subscribe( data =>{
      this.viewCtrl.dismiss();
    });
  }
 
  dismiss(){
    this.viewCtrl.dismiss();
  }
 
}

