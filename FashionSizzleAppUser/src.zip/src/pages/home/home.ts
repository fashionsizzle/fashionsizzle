import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {Api} from'../../providers/api';
import {Singale} from"../singale/singale"
import { AboutPage } from '../about/about'



@Component({
  selector: 'page-home',
  templateUrl: 'home.html',

  // templateUrl: 'home.html',
  providers: [Api]
})

export class HomePage 
{
  datas:any;

  constructor(public navCtrl: NavController, private api: Api) 
  {
    api.index(1).subscribe(data => 
    {
      this.datas = data.json();
    });
  }

   openSinglePage(url){
    this.navCtrl.push(Singale, {
      url:url
    })
  }

}
