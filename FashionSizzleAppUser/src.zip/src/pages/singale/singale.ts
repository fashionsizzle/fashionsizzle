import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {Http} from '@angular/http';
import{CommentPage} from '../comment/comment'

/**
 * Generated class for the Singale page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-singale',
  templateUrl: 'singale.html',
})
export class Singale {

  datas:any = [];
  comments:any;
  constructor(private navCtrl: NavController, params: NavParams, private http: Http) {
    console.log("trace url : ---" + params.data.url+"/?_embed");
    this.http.get(params.data.url+"/?_embed").subscribe(data=>{
      this.datas.push(data.json());

       console.log("trace url 2 : ---" + data.json()._links.replies[0].href);
      this.http.get(data.json()._links.replies[0].href).subscribe(comment=>{
        this.comments = comment.json()
      });

    });
  }
comment() 
{
    this.navCtrl.push(CommentPage);
}
  ionViewDidLoad() 
  {
    console.log('ionViewDidLoad Singale');
  }
}
